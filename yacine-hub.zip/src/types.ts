export interface Comment {
  id: number;
  author: string;
  content: string;
  rating: number;
  date: string;
}

export interface AppItem {
  id: number;
  title: string;
  type: "app" | "game";
  tag: string;
  desc: string;
  fullDesc: string;
  icon: string;
  downloadUrl: string;
  rating: number;
  downloadsCount: string;
  size: string;
  version: string;
  developer: string;
  screenshots: string[];
  comments: Comment[];
  isPremium?: boolean;
}

export interface DownloadState {
  itemId: number;
  progress: number;
  speed: string;
  status: "waiting" | "downloading" | "completed" | "paused" | "verifying";
}

export interface AppRequest {
  id: string;
  appName: string;
  type: "app" | "game";
  note: string;
  status: "pending" | "processing" | "available";
  createdAt: string;
}
