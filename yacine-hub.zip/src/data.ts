import { AppItem } from "./types";

export const INITIAL_ITEMS: AppItem[] = [
  {
    id: 1,
    title: "CapCut v18.2.0 (Pro)",
    type: "app",
    tag: "نسخة برو مفتوحة الميزات",
    desc: "أفضل تطبيق لتعديل ومونتاج الفيديو للهواتف الذكية مع تفعيل كافة الفلاتر والخطوط والميزات المدفوعة مجاناً.",
    fullDesc: "هو الأداة الاحترافية الأفضل للهواتف والأجهزة اللوحية لتصميم وتعديل مقاطع الفيديو بجودة سينمائية فائقة. تمنحك هذه النسخة المعدلة والمدفوعة (Pro Unlocked) ميزات غنية تشمل جميع فلاتر وتأثيرات الذكاء الاصطناعي، والخطوط العربية الفاخرة، بالإضافة إلى إزالة العلامة المائية تماماً وتصدير الفيديو بدقة 4K وبمعدل 60 إطاراً في الثانية بدون أي قيود.",
    icon: "https://i.ibb.co/GvHzP53M/capcut.png",
    downloadUrl: "https://www.mediafire.com/file/668v1jfconf5py6/CapCut+v18.2.0+(Pro)+Fix.apk/file",
    rating: 4.8,
    downloadsCount: "+10M",
    size: "135 MB",
    version: "18.2.0 (Pro Unlocked)",
    developer: "Bytedance Ltd.",
    isPremium: true,
    screenshots: [
      "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=600&q=80"
    ],
    comments: [
      { id: 1, author: "ياسين المغربي", content: "التطبيق شغال 100% والميزات الاحترافية مفتوحة بالكامل. شكراً جزيلاً!", rating: 5, date: "قبل ساعتين" },
      { id: 2, author: "سارة العتيبي", content: "روعة بدون علامة مائية وفلاتر الذكاء الاصطناعي رهيبة جداً.", rating: 5, date: "يوم أمس" },
      { id: 3, author: "أحمد الدوسري", content: "أفضل نسخة كاب كات حملتها بحياتي، سريعة ولا يوجد تعليق.", rating: 5, date: "قبل 3 أيام" }
    ]
  },
  {
    id: 2,
    title: "Reawait",
    type: "game",
    tag: "مغامرات 2D ممتعة",
    desc: "انطلق في رحلة مشوقة مليئة بالتحديات والمغامرات المثيرة في عالم ثنائي الأبعاد (2D) ساحر. واجه العقبات، واكتشف الأسرار، واستمتع بأسلوب لعب كلاسيكي ممتع.",
    fullDesc: "هي لعبة مغامرات وحركية كلاسيكية ساحرة بصيغة 2D. تأخذ اللاعب في رحلة خيالية عبر عوالم مخفية وغابات مسحورة مليئة بالكنوز والعقبات الصعبة والوحوش المتربصة. تتميز اللعبة بأسلوب تحكم مرن مخصص للهواتف، وتصميم مستويات غنية بالألغاز الذكية والمواجهات المصيرية، مما يعيد ذكريات الألعاب الكلاسيكية الخالدة بلمسة عصرية.",
    icon: "https://i.ibb.co/6c4c0s0v/app-icon.png",
    downloadUrl: "https://www.mediafire.com/file/w5ax1tryly8fka9/base.apk/file",
    rating: 4.6,
    downloadsCount: "+150K",
    size: "45 MB",
    version: "1.0.4 (Original)",
    developer: "Mogherbi Dev Studio",
    screenshots: [
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1551103782-8ab07afd45c1?auto=format&fit=crop&w=600&q=80"
    ],
    comments: [
      { id: 1, author: "حمزة بن علي", content: "لعبة تفاعلية جميلة جداً ورسوماتها خفيفة ومريحة للعين.", rating: 5, date: "قبل يومين" },
      { id: 2, author: "أمجد خالد", content: "الأشواط والمراحل متدرجة الصعوبة بشكل رائع، التحكم سلس للغاية.", rating: 4, date: "قبل 4 أيام" }
    ]
  }
];
