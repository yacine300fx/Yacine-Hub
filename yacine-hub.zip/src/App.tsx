import { useState, useEffect } from "react";
import { Star, ShieldAlert, BadgeCheck, ShieldCheck, Heart, Info, PlusCircle, AlertTriangle, ExternalLink, RefreshCw, X, DownloadCloud } from "lucide-react";
import Header from "./components/Header";
import HeroSection from "./components/HeroSection";
import AppCard from "./components/AppCard";
import DetailsModal from "./components/DetailsModal";
import DownloadQueue from "./components/DownloadQueue";
import RequestForm from "./components/RequestForm";
import AboutSection from "./components/AboutSection";
import AddAppForm from "./components/AddAppForm";
import { INITIAL_ITEMS } from "./data";
import { AppItem, Comment, DownloadState } from "./types";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [darkMode, setDarkMode] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<"all" | "app" | "game">("all");
  const [sortBy, setSortBy] = useState<"latest" | "rating" | "premium" | "size">("latest");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [activeTab, setActiveTab] = useState<"store" | "request" | "about" | "favorites" | "add-app">("store");
  
  // App data list with ratings, reviews, screenshots
  const [items, setItems] = useState<AppItem[]>(() => {
    const saved = localStorage.getItem("yacine_hub_items");
    let initialList = saved ? JSON.parse(saved) : INITIAL_ITEMS;
    // Explicitly filter out leftover redundant apps (ids 3, 4, 5, 6) that the AI previously added
    const redundantIds = [3, 4, 5, 6];
    return initialList.filter((item: AppItem) => !redundantIds.includes(item.id));
  });

  // Favorite IDs
  const [favorites, setFavorites] = useState<number[]>(() => {
    const saved = localStorage.getItem("yacine_hub_favorites");
    return saved ? JSON.parse(saved) : [];
  });

  // Selected Detail Modal target
  const [selectedItem, setSelectedItem] = useState<AppItem | null>(null);
  
  // Download Queue Manager
  const [downloadQueue, setDownloadQueue] = useState<DownloadState[]>([]);
  const [isDownloadDrawerOpen, setIsDownloadDrawerOpen] = useState(false);

  // Download Link Generator states
  const [preparingItem, setPreparingItem] = useState<AppItem | null>(null);
  const [preCountdown, setPreCountdown] = useState(5);
  const [scanStep, setScanStep] = useState("");

  // Keep states persisted
  useEffect(() => {
    localStorage.setItem("yacine_hub_items", JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem("yacine_hub_favorites", JSON.stringify(favorites));
  }, [favorites]);

  // Dark Mode application helper
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  // Periodic download speed simulation logic
  useEffect(() => {
    const interval = setInterval(() => {
      setDownloadQueue((prevQueue) => {
        let updated = false;
        const next = prevQueue.map((dl) => {
          if (dl.status === "downloading") {
            updated = true;
            const sizeInMb = parseFloat(dl.speed.split(" ")[0]) || 40;
            const inc = Math.floor(Math.random() * 12) + 6; // progress increment
            const currentProgress = Math.min(dl.progress + inc, 100);
            
            let status: "waiting" | "downloading" | "completed" | "paused" | "verifying" = dl.status;
            let currentSpeed = `${(Math.random() * 8 + 8).toFixed(1)} MB/s`;

            if (currentProgress >= 100) {
              status = "completed";
              currentSpeed = "رابط ميديا فاير جاهز الآن";
            }

            return {
              ...dl,
              progress: currentProgress,
              speed: currentSpeed,
              status
            };
          }
          return dl;
        });
        return updated ? next : prevQueue;
      });
    }, 1200);

    return () => clearInterval(interval);
  }, []);

  // Download Preparation Countdown Simulation
  useEffect(() => {
    if (!preparingItem) return;

    if (preCountdown > 0) {
      const texts = [
        "جاري استدعاء حبر الروابط المسرعة...",
        "جاري فحص التوقيعات الرقمية ومضادات الفيروسات سحابياً...",
        "التأكد من التوافق الفني وتكامل ملف التثبيت APK...",
        "الاتصال بالخادم المخصص لموقع Yacine Hub...",
        "استخراج رابط ميديا فاير المباشر الآمن..."
      ];
      setScanStep(texts[preCountdown - 1] || "جاري جرد الملفات...");

      const timer = setTimeout(() => {
        setPreCountdown((prev) => prev - 1);
      }, 1000);

      return () => clearTimeout(timer);
    } else {
      setScanStep("الرابط جاهز للتحميل الفوري! ✅ خالي من الفيروسات والبرامج الضارة وموثوق تماماً.");
    }
  }, [preparingItem, preCountdown]);

  // Handle addition & toggles
  const handleToggleFavorite = (id: number) => {
    setFavorites((prev) => 
      prev.includes(id) ? prev.filter((favId) => favId !== id) : [...prev, id]
    );
  };

  const startPreparationDownload = (item: AppItem) => {
    setPreCountdown(5);
    setPreparingItem(item);
  };

  const handleStartRealDownload = (item: AppItem) => {
    // Add file to active simulation queue
    setDownloadQueue((prev) => {
      const exists = prev.find((dl) => dl.itemId === item.id);
      if (exists) {
        if (exists.status === "completed") {
          return prev;
        }
        return prev.map((dl) => dl.itemId === item.id ? { ...dl, status: "downloading" } : dl);
      }

      return [
        ...prev,
        {
          itemId: item.id,
          progress: 5,
          speed: "12.4 MB/s",
          status: "downloading"
        }
      ];
    });

    // Close the countdown modal & open the active downloads side drawer
    setPreparingItem(null);
    setIsDownloadDrawerOpen(true);
  };

  // Pause or Resume simulated downloads
  const handlePauseToggle = (itemId: number) => {
    setDownloadQueue((prev) => 
      prev.map((dl) => 
        dl.itemId === itemId 
          ? { ...dl, status: dl.status === "paused" ? "downloading" : "paused" } 
          : dl
      )
    );
  };

  // Remove download task
  const handleRemoveDownload = (itemId: number) => {
    setDownloadQueue((prev) => prev.filter((dl) => dl.itemId !== itemId));
  };

  // Add a stateful Review comment inside details modal
  const handleAddComment = (itemId: number, commentInput: Omit<Comment, "id" | "date">) => {
    setItems((prevItems) => 
      prevItems.map((item) => {
        if (item.id === itemId) {
          const newComment: Comment = {
            id: Date.now(),
            author: commentInput.author,
            content: commentInput.content,
            rating: commentInput.rating,
            date: "الآن"
          };
          
          // Calculate rating average briefly
          const updatedComments = [newComment, ...item.comments];
          const sum = updatedComments.reduce((acc, c) => acc + c.rating, 0);
          const newAvg = parseFloat((sum / updatedComments.length).toFixed(1));

          return {
            ...item,
            comments: updatedComments,
            rating: newAvg
          };
        }
        return item;
      })
    );

    // Refresh selectedItem object to keep UI in sync
    setSelectedItem((prev) => {
      if (prev && prev.id === itemId) {
        const found = items.find((itm) => itm.id === itemId);
        if (found) {
          const updatedComments = [
            {
              id: Date.now(),
              author: commentInput.author,
              content: commentInput.content,
              rating: commentInput.rating,
              date: "الآن"
            },
            ...found.comments
          ];
          const sum = updatedComments.reduce((acc, c) => acc + c.rating, 0);
          const newAvg = parseFloat((sum / updatedComments.length).toFixed(1));

          return {
            ...prev,
            comments: updatedComments,
            rating: newAvg
          };
        }
      }
      return prev;
    });
  };

  // Filter and Sort dataset
  const filteredItems = items.filter((item) => {
    // 1. Category search
    if (selectedCategory !== "all" && item.type !== selectedCategory) {
      return false;
    }
    // 2. Text Search
    const query = searchQuery.trim().toLowerCase();
    if (query) {
      const matchTitle = item.title.toLowerCase().includes(query);
      const matchDesc = item.desc.toLowerCase().includes(query);
      const matchTag = item.tag.toLowerCase().includes(query);
      if (!matchTitle && !matchDesc && !matchTag) {
        return false;
      }
    }
    // 3. Favorites view
    if (activeTab === "favorites") {
      return favorites.includes(item.id);
    }

    return true;
  });

  // Sort logic sorting the items
  const sortedItems = [...filteredItems].sort((a, b) => {
    if (sortBy === "rating") {
      return b.rating - a.rating;
    }
    if (sortBy === "premium") {
      const aPrem = a.isPremium ? 1 : 0;
      const bPrem = b.isPremium ? 1 : 0;
      return bPrem - aPrem;
    }
    if (sortBy === "size") {
      const sizeA = parseInt(a.size) || 999;
      const sizeB = parseInt(b.size) || 999;
      return sizeA - sizeB;
    }
    return b.id - a.id; // defaults to latest id first
  });

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#1a0c02] text-amber-950 dark:text-amber-100 transition-colors duration-300 flex flex-col justify-between">
      
      {/* Header component integration */}
      <Header 
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          // If Tab state changes, scroll to app listing smoothly
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
        downloadCount={downloadQueue.filter((dl) => dl.status !== "completed").length}
        openDownloadDrawer={() => setIsDownloadDrawerOpen(true)}
        favCount={favorites.length}
      />

      {/* Main Tab content container */}
      <main className="flex-grow pb-16">
        
        {/* TAB 1: Main App Store view */}
        {activeTab === "store" && (
          <div>
            <HeroSection 
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              sortBy={sortBy}
              setSortBy={setSortBy}
              viewMode={viewMode}
              setViewMode={setViewMode}
            />

            {/* Render items grid/list panel */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
              
              {sortedItems.length === 0 ? (
                <div className="text-center py-20 bg-white dark:bg-amber-900/5 rounded-[2rem] border border-amber-100/40 dark:border-amber-900/10 space-y-4 max-w-3xl mx-auto">
                  <AlertTriangle className="w-16 h-16 mx-auto text-amber-500 animate-bounce" />
                  <h3 className="text-xl font-bold">لم نجد تطبيقات تطابق مخرجات بحثك!</h3>
                  <p className="text-sm text-amber-900/60 dark:text-amber-200/50 max-w-md mx-auto">
                    يمكنك كتابة طلب لتوفير هذا التطبيق أو اللعبة بالاسم بالتفصيل وسيقوم المطور برفعها على خوادم ميديا فاير في أقل من يوم!
                  </p>
                  <button
                    onClick={() => setActiveTab("request")}
                    className="px-6 py-3 bg-gradient-to-r from-orange-500 to-amber-500 text-white font-black rounded-xl text-xs"
                  >
                    اطلب رفع التطبيق الآن 🚀
                  </button>
                </div>
              ) : (
                <div className={
                  viewMode === "grid" 
                    ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8" 
                    : "space-y-4 max-w-5xl mx-auto"
                }>
                  {sortedItems.map((item) => (
                    <AppCard 
                      key={item.id}
                      item={item}
                      viewMode={viewMode}
                      onOpenDetails={(itm) => setSelectedItem(itm)}
                      onDownload={(itm) => startPreparationDownload(itm)}
                      isFavorite={favorites.includes(item.id)}
                      onToggleFavorite={handleToggleFavorite}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: Favorites view (Filters on same AppStore setup) */}
        {activeTab === "favorites" && (
          <div className="pt-8">
            <div className="max-w-7xl mx-auto px-4 text-center mb-10">
              <h2 className="text-2xl font-black text-rose-600 dark:text-rose-400">تطبيقاتك وألعابك المفضلة ❤️</h2>
              <p className="text-xs text-amber-900/60 dark:text-amber-200/50 font-semibold mt-1">تسهل عليك تتبع التطبيقات التي تحب تكرار تنزيلها أو استخدامها.</p>
            </div>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              {sortedItems.length === 0 ? (
                <div className="text-center py-20 bg-white dark:bg-amber-900/5 rounded-[2rem] border border-amber-100/40 dark:border-amber-900/10 space-y-4 max-w-3xl mx-auto">
                  <Heart className="w-16 h-16 mx-auto text-rose-300 animate-pulse" />
                  <h3 className="text-xl font-bold">لستة مفقودة! المفضلة فارغة حالياً</h3>
                  <p className="text-sm text-amber-905/60 dark:text-amber-200/50 max-w-md mx-auto">
                    تصفح المتجر واضغط على أيقونة القلب على أي تطبيق مهكر تود العودة لتنزيله بسهولة.
                  </p>
                  <button
                    onClick={() => setActiveTab("store")}
                    className="px-6 py-3 bg-amber-900 dark:bg-amber-100 text-white dark:text-amber-950 font-black rounded-xl text-xs"
                  >
                    العودة للمتجر
                  </button>
                </div>
              ) : (
                <div className={
                  viewMode === "grid" 
                    ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8" 
                    : "space-y-4 max-w-5xl mx-auto"
                }>
                  {sortedItems.map((item) => (
                    <AppCard 
                      key={item.id}
                      item={item}
                      viewMode={viewMode}
                      onOpenDetails={(itm) => setSelectedItem(itm)}
                      onDownload={(itm) => startPreparationDownload(itm)}
                      isFavorite={favorites.includes(item.id)}
                      onToggleFavorite={handleToggleFavorite}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: App Request submission page */}
        {activeTab === "request" && <RequestForm />}

        {/* TAB 4: About Website FAQ guarantees */}
        {activeTab === "about" && <AboutSection />}

        {/* TAB 5: Add App Page */}
        {activeTab === "add-app" && (
          <AddAppForm 
            onAddApp={(newApp) => {
              setItems((prev) => [newApp, ...prev]);
              setActiveTab("store");
            }} 
          />
        )}

      </main>

      {/* App Details Rich Dialog */}
      <AnimatePresence>
        {selectedItem && (
          <DetailsModal 
            item={selectedItem}
            onClose={() => setSelectedItem(null)}
            onDownload={(itm) => {
              setSelectedItem(null);
              startPreparationDownload(itm);
            }}
            onAddComment={handleAddComment}
            onDeleteApp={(itemId) => {
              setItems((prev) => prev.filter((itm) => itm.id !== itemId));
              setSelectedItem(null);
            }}
          />
        )}
      </AnimatePresence>

      {/* Floating simulated Active download Drawer */}
      <AnimatePresence>
        {isDownloadDrawerOpen && (
          <DownloadQueue 
            isOpen={isDownloadDrawerOpen}
            onClose={() => setIsDownloadDrawerOpen(false)}
            downloads={downloadQueue}
            allItems={items}
            onPauseToggle={handlePauseToggle}
            onRemove={handleRemoveDownload}
          />
        )}
      </AnimatePresence>

      {/* Links Generator / Antivirus scanning Countdown modal */}
      <AnimatePresence>
        {preparingItem && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-amber-955/85 backdrop-blur-md text-right">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-xl bg-white dark:bg-amber-950 border border-amber-100 dark:border-amber-900 rounded-[2.5rem] p-6 md:p-8 shadow-2xl space-y-6"
            >
              
              {/* Close Countdown modal handle */}
              <button
                onClick={() => setPreparingItem(null)}
                className="absolute top-5 left-5 p-2 bg-amber-50 hover:bg-amber-100 dark:bg-amber-900/40 text-amber-950 dark:text-amber-200 rounded-full"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="text-center space-y-3">
                <div className="relative inline-flex items-center justify-center p-4 bg-orange-100 dark:bg-amber-900/40 rounded-full text-orange-600 dark:text-amber-400 mb-2">
                  <DownloadCloud className="w-8 h-8 animate-bounce" />
                  {preCountdown > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-orange-600 text-white font-black text-xs flex items-center justify-center animate-ping"></span>
                  )}
                </div>

                <h3 className="text-xl font-black text-amber-950 dark:text-white">
                  يتم تحضير رابط التحميل الآمن...
                </h3>
                
                <p className="text-xs text-amber-900/60 dark:text-amber-200/50 font-bold">
                  تطبيق: <span className="text-orange-600 dark:text-amber-400">{preparingItem.title}</span> ({preparingItem.size})
                </p>
              </div>

              {/* Progress Scanner state representation */}
              <div className="p-4 bg-amber-50/50 dark:bg-amber-900/10 border border-amber-100/30 dark:border-amber-900/30 rounded-2xl space-y-4">
                
                {/* Visual percentage slider */}
                <div className="space-y-1.5">
                  <div className="w-full bg-amber-200/50 dark:bg-amber-900/30 h-3 rounded-full overflow-hidden">
                    <div 
                      className="bg-gradient-to-l from-orange-500 to-amber-500 h-full transition-all duration-300"
                      style={{ width: `${(5 - preCountdown) * 20}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-[10px] font-bold text-amber-900/50 dark:text-amber-200/40">
                    <span>حالة الفحص والمصادقة:</span>
                    <span>{100 - preCountdown * 20}%</span>
                  </div>
                </div>

                {/* Checklist scanner text updates */}
                <div className="grid grid-cols-1 gap-2.5 text-xs font-bold text-amber-950 dark:text-amber-100">
                  <div className="flex items-center gap-2">
                    <span className={preCountdown <= 4 ? "text-emerald-500" : "text-amber-500"}>
                      {preCountdown <= 4 ? "✅" : "⏳"}
                    </span>
                    <span className={preCountdown <= 4 ? "opacity-100" : "opacity-40"}>أمان التوقيعات الرقمية خالية من الاختراقات</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={preCountdown <= 3 ? "text-emerald-500" : "text-amber-500"}>
                      {preCountdown <= 3 ? "✅" : "⏳"}
                    </span>
                    <span className={preCountdown <= 3 ? "opacity-100" : "opacity-40"}>فحص مضادات الفيروسات السحابية (Clean Archive)</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className={preCountdown <= 2 ? "text-emerald-500" : "text-amber-500"}>
                      {preCountdown <= 2 ? "✅" : "⏳"}
                    </span>
                    <span className={preCountdown <= 2 ? "opacity-100" : "opacity-40"}>توافق أنظمة الاندرويد للهاتف الأصلي والمعدل</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={preCountdown <= 1 ? "text-emerald-500" : "text-amber-500"}>
                      {preCountdown <= 1 ? "✅" : "⏳"}
                    </span>
                    <span className={preCountdown <= 1 ? "opacity-100" : "opacity-40"}>رابط مرآة Mediafire وحالة خوادم ياسين هب</span>
                  </div>
                </div>

                <div className="text-center pt-2 border-t border-amber-100/40 text-[11px] font-bold text-orange-600 dark:text-amber-400">
                  {scanStep}
                </div>
              </div>

              {/* Action output */}
              <div className="pt-2">
                {preCountdown > 0 ? (
                  <div className="w-full text-center py-3.5 bg-amber-50 dark:bg-amber-900/20 text-amber-800 dark:text-amber-200 font-extrabold text-xs rounded-xl cursor-not-allowed">
                    جاري إتاحة التحميل الآمن... ({preCountdown} ثوانٍ)
                  </div>
                ) : (
                  <div className="space-y-3">
                    <button
                      onClick={() => handleStartRealDownload(preparingItem)}
                      className="w-full text-center py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-black text-xs sm:text-sm rounded-xl hover:from-emerald-600 hover:to-teal-700 transition shadow-lg shadow-emerald-555/20 animate-pulse"
                    >
                      بدء تنزيل ملف الـ APK المباشر السريع الآن 🚀
                    </button>
                    
                    <a
                      href={preparingItem.downloadUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex w-full items-center justify-center gap-2 text-center text-xs font-black text-amber-900 hover:text-amber-950 dark:text-amber-100 dark:hover:text-white"
                    >
                      <span>تخطي والذهاب مباشرة لصفحة MediaFire الأصلية</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                )}
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer Branding credits */}
      <footer className="bg-white dark:bg-[#110801] border-t border-amber-100 dark:border-amber-900/30 py-8 text-center text-xs font-semibold text-amber-900/50 dark:text-amber-250/30 px-4 space-y-2">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p>© 2026 متجر Yacine Hub لتنزيل الألعاب والتطبيقات المدفوعة مجاناً. جميع الحقوق محفوظة لـ Yacine Studio.</p>
          <div className="flex gap-4">
            <span className="hover:text-orange-500 cursor-pointer" onClick={() => setActiveTab("about")}>سياسة الأمان والضمان</span>
            <span>•</span>
            <span className="hover:text-orange-500 cursor-pointer" onClick={() => setActiveTab("request")}>اتصل بالمطور</span>
          </div>
        </div>
      </footer>

    </div>
  );
}

