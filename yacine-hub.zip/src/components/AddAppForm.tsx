import { useState, FormEvent, startTransition } from "react";
import { PlusCircle, ShieldCheck, Link, Sparkles, Image, CheckCircle, Smartphone } from "lucide-react";
import { AppItem } from "../types";

interface AddAppFormProps {
  onAddApp: (newApp: AppItem) => void;
}

const DEFAULT_ICONS = [
  { label: "أيقونة افتراضية", url: "https://i.ibb.co/6c4c0s0v/app-icon.png" },
  { label: "كاب كات", url: "https://i.ibb.co/GvHzP53M/capcut.png" },
  { label: "بيكس ارت", url: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=120&h=120&q=80" },
  { label: "ماين كرافت", url: "https://images.unsplash.com/photo-1627856013091-fed6e4e30025?auto=format&fit=crop&w=120&h=120&q=80" },
  { label: "تعديل صور", url: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=120&h=120&q=80" },
];

export default function AddAppForm({ onAddApp }: AddAppFormProps) {
  const [title, setTitle] = useState("");
  const [type, setType] = useState<"app" | "game">("app");
  const [tag, setTag] = useState("");
  const [desc, setDesc] = useState("");
  const [fullDesc, setFullDesc] = useState("");
  const [icon, setIcon] = useState("https://i.ibb.co/6c4c0s0v/app-icon.png");
  const [downloadUrl, setDownloadUrl] = useState("");
  const [size, setSize] = useState("");
  const [version, setVersion] = useState("");
  const [developer, setDeveloper] = useState("");
  const [screenshots, setScreenshots] = useState("");
  const [downloadsCount, setDownloadsCount] = useState("+1K");
  const [isPremium, setIsPremium] = useState(true);
  
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !downloadUrl.trim()) return;

    // Process screenshots: split by commas or newlines, filter empty, or use defaults
    let screenshotList = screenshots
      .split(/[\n,]+/)
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    if (screenshotList.length === 0) {
      screenshotList = [
        "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=600&q=80"
      ];
    }

    const newApp: AppItem = {
      id: Date.now(),
      title: title.trim(),
      type,
      tag: tag.trim() || (type === "app" ? "نسخة مفعّلة بالكامل" : "مفتوحة بالكامل مجاناً"),
      desc: desc.trim() || `تنزيل مباشر وسريع لتطبيق ${title} المعدل بأحدث الميزات الحصرية مجاناً.`,
      fullDesc: fullDesc.trim() || `هذه هي النسخة المهكرة والمعدلة بالكامل من ${title}. تم فحصها سحابياً لضمان خلوها من الإعلانات والأكواد الضارة، مما يتيح لك تجربة استخدام كاملة وآمنة بنسبة 100% مع ميزات حصرية مجانية للجميع.`,
      icon: icon.trim() || "https://i.ibb.co/6c4c0s0v/app-icon.png",
      downloadUrl: downloadUrl.trim(),
      rating: 5.0,
      downloadsCount: downloadsCount.trim() || "+10K",
      size: size.trim() || "50 MB",
      version: version.trim() || "1.0.0 (Pro)",
      developer: developer.trim() || "Mogherbi Dev Studio",
      screenshots: screenshotList,
      comments: [
        {
          id: Date.now() + 1,
          author: "ياسين هب بوت",
          content: "تم فحص هذا التطبيق بأحدث خوارزميات الفحص وتأكيد سلامة ملف الـ APK وتوافق الروابط المسرعة.",
          rating: 5,
          date: "الآن"
        }
      ],
      isPremium
    };

    onAddApp(newApp);

    // Clear form
    setTitle("");
    setTag("");
    setDesc("");
    setFullDesc("");
    setDownloadUrl("");
    setSize("");
    setVersion("");
    setDeveloper("");
    setScreenshots("");
    setDownloadsCount("+1K");
    setIsPremium(true);

    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
    }, 5000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 md:py-12 text-right">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <h2 className="text-3xl font-black text-white flex items-center justify-center gap-2">
          <Sparkles className="w-7 h-7 text-indigo-400" />
          <span>إضافة تطبيق/لعبة للمتجر 🚀</span>
        </h2>
        <p className="mt-2 text-sm text-slate-400 font-semibold">
          قم بملء تفاصيل الأبليكيشن لرفعه وإضافته فوراً إلى قائمة المتجر الرئيسي. سيتم حفظه تلقائياً في المتصفح!
        </p>
      </div>

      <div className="bg-[#12151e] border border-slate-800 rounded-[2.5rem] p-6 md:p-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

        {showSuccess && (
          <div className="mb-8 p-5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-2xl font-bold text-sm flex items-center gap-3">
            <CheckCircle className="w-6 h-6 text-emerald-400 flex-shrink-0" />
            <div>
              <p className="font-black">تم نشر وإضافة التطبيق بنجاح! 🎉</p>
              <p className="text-xs text-emerald-500/80 mt-1">اذهب إلى "المتجر الرئيسي" لتجربته وفحصه وتحميله مباشرة.</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Title */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300">اسم التطبيق/اللعبة بالكامل *</label>
              <input 
                type="text" 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                placeholder="مثال: CapCut v18 (Pro)"
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              />
            </div>

            {/* Main Type */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300">التصنيف الرئيسي *</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setType("app")}
                  className={`py-3 rounded-xl text-xs font-black transition ${
                    type === "app"
                      ? "bg-indigo-600/25 text-indigo-400 border border-indigo-500/40 shadow-sm"
                      : "bg-[#0a0c14] border border-slate-800 text-slate-400 font-bold hover:bg-slate-800/40"
                  }`}
                >
                  أبلكيشن / تطبيق 📱
                </button>
                <button
                  type="button"
                  onClick={() => setType("game")}
                  className={`py-3 rounded-xl text-xs font-black transition ${
                    type === "game"
                      ? "bg-indigo-600/25 text-indigo-400 border border-indigo-500/40 shadow-sm"
                      : "bg-[#0a0c14] border border-slate-800 text-slate-400 font-bold hover:bg-slate-800/40"
                  }`}
                >
                  لعبة أندرويد 🎮
                </button>
              </div>
            </div>

            {/* Mediafire Link */}
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-black text-slate-300">رابط تحميل ميديا فاير المباشر (Mediafire URL) *</label>
              <div className="relative">
                <Link className="absolute top-3.5 right-4 w-4 h-4 text-indigo-400 pointer-events-none" />
                <input 
                  type="url" 
                  value={downloadUrl}
                  onChange={(e) => setDownloadUrl(e.target.value)}
                  required
                  placeholder="https://www.mediafire.com/file/..."
                  className="w-full pr-11 pl-4 py-3.5 bg-[#0a0c14] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
                />
              </div>
            </div>

            {/* Tag */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300">شارة التعديل / Tag</label>
              <input 
                type="text" 
                value={tag}
                onChange={(e) => setTag(e.target.value)}
                placeholder="مثال: نسخة برو مهكرة بالكامل"
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              />
            </div>

            {/* Developer */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300">اسم المطور المبرمج</label>
              <input 
                type="text" 
                value={developer}
                onChange={(e) => setDeveloper(e.target.value)}
                placeholder="مثال: Mogherbi Dev Studio"
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              />
            </div>

            {/* Version */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300">رقم إصدار APK</label>
              <input 
                type="text" 
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                placeholder="مثال: v18.2.0 (Pro)"
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              />
            </div>

            {/* Size */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300">الحجم الكلي للملف</label>
              <input 
                type="text" 
                value={size}
                onChange={(e) => setSize(e.target.value)}
                placeholder="مثال: 135 MB"
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              />
            </div>

            {/* Icon Picker & Input */}
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-black text-slate-300">رابط صورة أيقونة التطبيق (URL)</label>
              <input 
                type="url" 
                value={icon}
                onChange={(e) => setIcon(e.target.value)}
                placeholder="أدخل رابط أيقونة مباشر أو اختر من الافتراضية"
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              />
              <div className="flex flex-wrap items-center gap-2 mt-2">
                <span className="text-[10px] font-bold text-slate-400">أيائل سريعة للأيقونات:</span>
                {DEFAULT_ICONS.map((ic, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => startTransition(() => setIcon(ic.url))}
                    className={`px-2.5 py-1 text-[10px] rounded-lg border font-bold transition ${
                      icon === ic.url 
                        ? "bg-indigo-600/20 text-indigo-400 border-indigo-500/50" 
                        : "bg-[#0a0c14] text-slate-400 border-slate-800 hover:text-white"
                    }`}
                  >
                    {ic.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Screenshots list input */}
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-black text-slate-300">روابط لقطات الشاشة للتجربة (مفصولة بفواصل كوبي أو سطر، اختياري)</label>
              <textarea
                value={screenshots}
                onChange={(e) => setScreenshots(e.target.value)}
                placeholder="https://image-link-1.png&#10;https://image-link-2.png"
                rows={2}
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-semibold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              ></textarea>
            </div>

            {/* Premium flag */}
            <div className="flex items-center gap-3 py-2">
              <input 
                type="checkbox" 
                id="isPremiumCheck"
                checked={isPremium}
                onChange={(e) => setIsPremium(e.target.checked)}
                className="w-4.5 h-4.5 rounded text-indigo-600 focus:ring-indigo-500 bg-[#0a0c14] border-slate-800"
              />
              <label htmlFor="isPremiumCheck" className="text-xs font-black text-slate-300 cursor-pointer select-none">
                بريميوم معدل / ذهبي (Premium VIP) ⭐
              </label>
            </div>

            {/* Downloads count */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300">مجموع التحميلات الوهمي الترويجي</label>
              <input 
                type="text" 
                value={downloadsCount}
                onChange={(e) => setDownloadsCount(e.target.value)}
                placeholder="مثال: +10K"
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              />
            </div>

            {/* Short description */}
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-black text-slate-300">مخلص قصير للتعديل *</label>
              <input 
                type="text" 
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
                required
                placeholder="أفضل تطبيق لتعديل صورك وتفعيل فلاتر كامل الميزات مجاناً..."
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              />
            </div>

            {/* Full description */}
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-black text-slate-300">الوصف الكامل والتفصيلي للمميزات</label>
              <textarea
                value={fullDesc}
                onChange={(e) => setFullDesc(e.target.value)}
                placeholder="اكتب بالتفصيل ما الذي تم تجميده، تفعيله أو إضافته في هذه النسخة المعدلة لكي يعرف الزائر الميزات الحقيقية..."
                rows={5}
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-medium rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              ></textarea>
            </div>

          </div>

          <div className="pt-4">
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2.5 py-4 bg-indigo-600 hover:bg-indigo-550 text-white font-black text-sm rounded-xl transition shadow-lg shadow-indigo-600/20"
            >
              <PlusCircle className="w-5 h-5" />
              <span>إضافة الأبلكيشن ونشره في المتجر فوراً</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
