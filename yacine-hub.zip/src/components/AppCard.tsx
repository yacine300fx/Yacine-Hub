import { Star, ArrowLeft, Download, ShieldAlert, BadgeCheck, Heart } from "lucide-react";
import { AppItem } from "../types";
import { motion } from "motion/react";

interface AppCardProps {
  item: AppItem;
  viewMode: "grid" | "list";
  onOpenDetails: (item: AppItem) => void;
  onDownload: (item: AppItem) => void;
  isFavorite: boolean;
  onToggleFavorite: (itemId: number) => void;
}

export default function AppCard({
  item,
  viewMode,
  onOpenDetails,
  onDownload,
  isFavorite,
  onToggleFavorite
}: AppCardProps) {
  
  if (viewMode === "list") {
    return (
      <motion.div
        layout
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.98 }}
        transition={{ duration: 0.3 }}
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 bg-[#12151e] border border-slate-800/80 rounded-3xl hover:border-indigo-500/50 hover:shadow-[0_0_20px_rgba(79,70,229,0.15)] transition-all duration-300 group"
      >
        <div className="flex items-center gap-4 cursor-pointer w-full sm:w-auto" onClick={() => onOpenDetails(item)}>
          <div className="relative flex-shrink-0">
            <img 
              src={item.icon} 
              alt={item.title} 
              className="w-16 h-16 rounded-2xl object-cover bg-slate-900 border border-slate-800 group-hover:scale-105 transition-all duration-300"
              referrerPolicy="no-referrer"
            />
            {item.isPremium && (
              <span className="absolute -top-1.5 -right-1.5 px-2 py-0.5 text-[9px] bg-indigo-600 font-bold text-white rounded-lg shadow-md border border-indigo-500/30">
                برو
              </span>
            )}
          </div>
          
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap text-right">
              <h3 className="font-black text-white text-base group-hover:text-indigo-400 transition">
                {item.title}
              </h3>
              <span className="px-2 py-0.5 text-[10px] bg-indigo-500/10 font-bold text-indigo-300 rounded-full border border-indigo-500/20">
                {item.tag}
              </span>
            </div>
            
            <p className="text-xs text-slate-400 line-clamp-1 max-w-xl text-right">
              {item.desc}
            </p>

            <div className="flex items-center gap-3 text-xs text-slate-500 font-bold">
              <span className="flex items-center gap-1 text-amber-500" dir="ltr">
                <Star className="w-3.5 h-3.5 fill-current" />
                {item.rating}
              </span>
              <span>•</span>
              <span dir="ltr">{item.size}</span>
              <span>•</span>
              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded text-[10px]">
                {item.type === "app" ? "تطبيق" : "لعبة"}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end border-t border-slate-800/40 sm:border-0 pt-3 sm:pt-0">
          <button
            onClick={() => onToggleFavorite(item.id)}
            className={`p-2 rounded-xl transition-all ${
              isFavorite 
                ? "bg-pink-500/10 text-pink-400 hover:bg-pink-505/20" 
                : "bg-slate-800/40 text-slate-400 hover:text-pink-400"
            }`}
            title="أضف للمفضلة"
          >
            <Heart className={`w-4 h-4 ${isFavorite ? "fill-current" : ""}`} />
          </button>
          
          <button
            onClick={() => onOpenDetails(item)}
            className="px-4 py-2 text-xs font-black text-slate-300 bg-slate-800/55 hover:bg-slate-800 rounded-xl transition duration-150 border border-slate-700/40"
          >
            التفاصيل القيمة
          </button>
          
          <button
            onClick={() => onDownload(item)}
            className="flex items-center gap-2 px-5 py-2.5 bg-indigo-650/15 border border-indigo-500/30 text-indigo-400 hover:bg-indigo-600 hover:text-white hover:border-indigo-600 transition duration-150 rounded-xl font-black text-xs shadow-md"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تحميل مباشر</span>
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.4 }}
      className="flex flex-col bg-[#12151e] border border-slate-800 rounded-[2rem] overflow-hidden hover:border-indigo-500/50 hover:shadow-[0_12px_40px_rgba(0,0,0,0.6)] hover:shadow-indigo-500/5 transition-all duration-300 group relative"
    >
      {/* Favorite Heart Toggler */}
      <button
        onClick={() => onToggleFavorite(item.id)}
        className={`absolute top-4 right-4 z-10 p-2.5 rounded-full backdrop-blur-md transition-all ${
          isFavorite
            ? "bg-pink-500/10 text-pink-400 border border-pink-550/30 shadow-md"
            : "bg-slate-900/80 text-slate-400 hover:text-pink-400 shadow-sm"
        }`}
      >
        <Heart className={`w-4 h-4 ${isFavorite ? "fill-current" : ""}`} />
      </button>

      {/* Card Header Illustration/Background (Color coded) */}
      <div className={`h-28 flex items-end px-6 pb-4 relative overflow-hidden bg-gradient-to-br ${
        item.type === "app" 
          ? "from-indigo-600/20 via-purple-500/5 to-transparent" 
          : "from-pink-600/20 via-purple-500/5 to-transparent"
      }`}>
        <div className="absolute top-4 left-4 px-2.5 py-1 text-[10px] font-black rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-sm flex items-center gap-1">
          <BadgeCheck className="w-3 h-3 text-emerald-400" />
          <span>آمن ومفحوص</span>
        </div>
      </div>

      {/* Main Content Info */}
      <div className="px-6 pb-6 pt-0 flex-1 flex flex-col justify-between -mt-8 relative">
        <div>
          {/* Circular App icon */}
          <div className="relative inline-block mb-3">
            <img 
              src={item.icon} 
              alt={item.title} 
              onClick={() => onOpenDetails(item)}
              className="w-16 h-16 rounded-2xl object-cover border-4 border-[#12151e] shadow-md cursor-pointer group-hover:scale-105 transition duration-300 bg-slate-900"
              referrerPolicy="no-referrer"
            />
            {item.isPremium && (
              <span className="absolute bottom-0 -right-1 px-1.5 py-0.5 bg-indigo-600 text-white text-[8px] font-black tracking-wider rounded-md shadow-sm border border-[#12151e]">
                برو
              </span>
            )}
          </div>

          {/* Title & tag */}
          <div className="space-y-1.5 text-right">
            <h3 
              onClick={() => onOpenDetails(item)}
              className="text-base font-black text-white cursor-pointer group-hover:text-indigo-400 transition line-clamp-1"
            >
              {item.title}
            </h3>
            
            <span className="inline-block px-2 py-0.5 text-[9px] font-bold text-indigo-300 bg-indigo-500/10 border border-indigo-500/25 rounded-lg">
              {item.tag}
            </span>

            <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed pt-1.5">
              {item.desc}
            </p>
          </div>
        </div>

        {/* Footer Meta details & direct buttons */}
        <div className="mt-5 space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold border-t border-slate-800/40 pt-3">
            <span className="flex items-center gap-1 text-amber-500" dir="ltr">
              <Star className="w-3.5 h-3.5 fill-current" />
              {item.rating}
            </span>
            <span dir="ltr">{item.size}</span>
            <span className="capitalize px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-400">
              {item.type === "app" ? "تطبيقات" : "ألعاب"}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              id={`details-btn-${item.id}`}
              onClick={() => onOpenDetails(item)}
              className="flex-1 py-2.5 text-xs font-black text-slate-300 bg-slate-800 hover:bg-slate-700/80 rounded-[1.25rem] transition duration-150 border border-slate-700/30"
            >
              التفاصيل
            </button>
            
            <button
              id={`download-btn-${item.id}`}
              onClick={() => onDownload(item)}
              className="px-4 py-2.5 bg-indigo-600 text-white hover:bg-indigo-500 hover:shadow-[0_0_15px_rgba(79,70,229,0.35)] rounded-[1.25rem] transition duration-150"
              title="تحميل مباشر الآن"
            >
              <Download className="w-4 h-4 animate-bounce" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
