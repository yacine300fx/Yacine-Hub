import { X, Play, Pause, CheckCircle, DownloadCloud, AlertCircle, ExternalLink } from "lucide-react";
import { DownloadState, AppItem } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface DownloadQueueProps {
  isOpen: boolean;
  onClose: () => void;
  downloads: DownloadState[];
  allItems: AppItem[];
  onPauseToggle: (itemId: number) => void;
  onRemove: (itemId: number) => void;
}

export default function DownloadQueue({
  isOpen,
  onClose,
  downloads,
  allItems,
  onPauseToggle,
  onRemove
}: DownloadQueueProps) {
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 left-0 bg-transparent z-50 flex justify-start text-right">
      
      {/* Dark overlay backdrop */}
      <div 
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm"
      ></div>

      {/* Main Drawer Shell */}
      <motion.div
        initial={{ x: "-100%" }}
        animate={{ x: 0 }}
        exit={{ x: "-100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 180 }}
        className="relative w-80 sm:w-96 bg-[#0a0c14] border-r border-slate-800/80 h-full p-6 shadow-2xl flex flex-col justify-between"
      >
        
        <div>
          {/* Drawer Header */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
            <h3 className="font-black text-lg text-white flex items-center gap-2">
              <DownloadCloud className="w-5 h-5 text-indigo-400" />
              <span>مدير التنزيلات الآمنة</span>
            </h3>
            
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded-full bg-slate-800/45 hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Stats Banner */}
          <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20 mb-6 text-xs text-indigo-200 font-semibold space-y-1">
            <p>🛡️ فحص الفيروسات نشط كلياً لمصداقية المتجر.</p>
            <p>🌐 يتم تحميل روابط ميديا فاير مباشرة بدون التفاف.</p>
          </div>

          {/* Downloads Queue List */}
          <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
            {downloads.length === 0 ? (
              <div className="text-center py-12 text-slate-600 space-y-2">
                <AlertCircle className="w-10 h-10 mx-auto text-slate-700" />
                <p className="font-black text-sm text-slate-400">لا توجد تنزيلات جارية حالياً</p>
                <p className="text-[10px] leading-relaxed max-w-xs mx-auto">تصفح لستة التطبيقات الرائعة واضغط على زر التحميل لتجربة الخدمة الفائقة.</p>
              </div>
            ) : (
              downloads.map((dl) => {
                const searchItem = allItems.find((itm) => itm.id === dl.itemId);
                if (!searchItem) return null;
                
                const isCompleted = dl.status === "completed";
                const isPaused = dl.status === "paused";
                const isVerifying = dl.status === "verifying";

                return (
                  <div 
                    key={dl.itemId}
                    className="p-4 bg-[#12151e] border border-slate-800/85 rounded-2xl space-y-3"
                  >
                    {/* Item title & icon */}
                    <div className="flex items-center gap-3">
                      <img 
                        src={searchItem.icon} 
                        alt={searchItem.title} 
                        className="w-10 h-10 rounded-xl object-cover bg-slate-900"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-black text-xs text-white truncate">
                          {searchItem.title}
                        </h4>
                        <div className="flex items-center justify-between mt-0.5">
                          <span className="text-[9px] font-bold text-slate-500" dir="ltr">
                            {dl.speed ? dl.speed : `${searchItem.size}`}
                          </span>
                          <span className={`${
                            isCompleted ? "text-emerald-400" : isVerifying ? "text-indigo-400 animate-pulse" : isPaused ? "text-amber-500" : "text-indigo-400"
                          } text-[9px] font-black`}>
                            {isCompleted ? "تم التنزيل بنجاح ✅" : isVerifying ? "جاري التحقق الأمني..." : isPaused ? "مؤقتًا" : "جاري التنزيل..."}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="space-y-1">
                      <div className="w-full bg-slate-800/40 h-2 rounded-full overflow-hidden">
                        <div 
                          className={`h-full transition-all duration-300 ${
                            isCompleted ? "bg-emerald-500" : isVerifying ? "bg-indigo-500 animate-pulse" : isPaused ? "bg-amber-500" : "bg-gradient-to-r from-indigo-500 to-pink-500"
                          }`}
                          style={{ width: `${dl.progress}%` }}
                        ></div>
                      </div>
                      <div className="flex justify-between text-[10px] font-bold text-slate-500">
                        <span dir="ltr">{dl.progress}%</span>
                        <span dir="ltr">APK package</span>
                      </div>
                    </div>

                    {/* Controls Footer */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-800/40">
                      <button
                        onClick={() => onRemove(dl.itemId)}
                        className="text-[10px] text-pink-500 hover:text-pink-400 font-bold"
                      >
                        إلغاء وإزالة
                      </button>

                      <div className="flex items-center gap-2">
                        {!isCompleted && !isVerifying && (
                          <button
                            onClick={() => onPauseToggle(dl.itemId)}
                            className="p-1 px-2 text-[10px] font-black bg-slate-800 text-slate-300 rounded-lg flex items-center gap-1 hover:bg-slate-700 transition"
                          >
                            {isPaused ? <Play className="w-2.5 h-2.5" /> : <Pause className="w-2.5 h-2.5" />}
                            <span>{isPaused ? "استئناف" : "إيقاف مؤقت"}</span>
                          </button>
                        )}
                        
                        {isCompleted && (
                          <a
                            href={searchItem.downloadUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1 px-2.5 text-[10px] font-black bg-indigo-600 text-white rounded-lg flex items-center gap-1 hover:bg-indigo-500 transition hover:shadow-[0_0_10px_rgba(79,70,229,0.35)]"
                          >
                            <ExternalLink className="w-2.5 h-2.5" />
                            <span>فتح MediaFire</span>
                          </a>
                        )}
                      </div>
                    </div>

                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Drawer Footer info */}
        <div className="text-center text-[10px] text-slate-500 font-bold border-t border-slate-800/50 pt-4">
          ملفات APK منتهية بالكامل جاهزة للتنصيب الآمن.
        </div>

      </motion.div>
    </div>
  );
}
