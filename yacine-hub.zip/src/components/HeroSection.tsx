import { Search, Flame, Shield, Zap, Sparkles, SlidersHorizontal, Grid, List } from "lucide-react";
import { motion } from "motion/react";

interface HeroSectionProps {
  searchQuery: string;
  setSearchQuery: (val: string) => void;
  selectedCategory: "all" | "app" | "game";
  setSelectedCategory: (val: "all" | "app" | "game") => void;
  sortBy: "latest" | "rating" | "premium" | "size";
  setSortBy: (val: "latest" | "rating" | "premium" | "size") => void;
  viewMode: "grid" | "list";
  setViewMode: (val: "grid" | "list") => void;
}

export default function HeroSection({
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  sortBy,
  setSortBy,
  viewMode,
  setViewMode
}: HeroSectionProps) {
  
  const categories = [
    { id: "all", label: "جميع الإضافات", count: 6 },
    { id: "app", label: "تطبيقات برو", count: 3 },
    { id: "game", label: "ألعاب ممتعة", count: 3 }
  ] as const;

  return (
    <div className="relative py-12 md:py-20 overflow-hidden bg-[#05060a]">
      
      {/* Background Grid Accent */}
      <div className="absolute inset-0 grid grid-cols-6 grid-rows-6 opacity-10 pointer-events-none">
        <div className="border border-indigo-500/20"></div><div className="border border-indigo-500/20"></div><div className="border border-indigo-500/20"></div><div className="border border-indigo-500/20"></div><div className="border border-indigo-500/20"></div><div className="border border-indigo-500/20"></div>
        <div className="border border-indigo-500/20"></div><div className="border border-indigo-500/20"></div><div className="border border-indigo-500/20"></div><div className="border border-indigo-500/20"></div><div className="border border-indigo-500/20"></div><div className="border border-indigo-500/20"></div>
      </div>

      {/* Decorative Blur Background elements */}
      <div className="absolute top-[-100px] right-[-100px] w-[600px] h-[600px] bg-indigo-600/10 rounded-full blur-[130px] pointer-events-none"></div>
      <div className="absolute bottom-5 left-10 w-[500px] h-[500px] bg-pink-600/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center">
        
        {/* Banner Announcement */}
        <motion.div 
          initial={{ opacity: 0, y: -15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 mb-6"
        >
          <Flame className="w-4 h-4 text-indigo-400 animate-pulse" />
          <span className="text-xs font-bold text-indigo-300">
            تحديث يونيو 2026: تمت إضافة CapCut Pro v18.2.0 معدل و Reawait الأصلي!
          </span>
          <span className="bg-indigo-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-[0_0_10px_rgba(79,70,229,0.5)]">جديد</span>
        </motion.div>
 
        {/* Brand Headline */}
        <motion.h1 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-3xl sm:text-5xl md:text-6xl font-black text-white tracking-tight leading-tight max-w-4xl mx-auto"
        >
          حمل أحدث الألعاب والتطبيقات 
          <span className="block mt-2 text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 drop-shadow-[0_0_15px_rgba(168,85,247,0.3)]">
            مجاناً بروابط ميديا فاير مباشرة آمنة
          </span>
        </motion.h1>

        {/* Brand Subheader */}
        <motion.p 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-6 text-sm sm:text-lg text-slate-300 max-w-2xl mx-auto font-medium"
        >
          نحن نوفر لك أفضل تطبيق برو للأندرويد بروابط مباشرة وآمنة. لا حاجة للتسجيل، ولا إعلانات منبثقة مزعجة، فقط متعة التنزيل المباشر!
        </motion.p>

        {/* Core Value Proposition badges */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-wrap justify-center gap-4 mt-8 max-w-3xl mx-auto"
        >
          <div className="flex items-center gap-2 px-4 py-2 bg-[#12151e] border border-slate-800/50 rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold text-slate-300">فحص سحابي ضد البرمجيات الخبيثة</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-[#12151e] border border-slate-800/50 rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
            <Zap className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-bold text-slate-300">روابط MediaFire مباشرة وسريعة</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-[#12151e] border border-slate-800/50 rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
            <Sparkles className="w-4 h-4 text-pink-400" />
            <span className="text-xs font-bold text-slate-300">تحديثات أمنية دورية وحصرية</span>
          </div>
        </motion.div>

        {/* Interactive Deep Search input */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-12 max-w-2xl mx-auto"
        >
          <div className="relative group">
            <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 blur opacity-30 group-hover:opacity-60 transition duration-300"></div>
            <div className="relative flex items-center bg-[#12151e] border border-slate-800 rounded-full shadow-2xl overflow-hidden p-1">
              <div className="pr-4 py-3 text-slate-400">
                <Search className="w-6 h-6 animate-pulse" />
              </div>
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث عن ألعاب، وتطبيقات برو، ومونتاج مثل CapCut..." 
                className="w-full bg-transparent border-0 ring-0 focus:outline-none focus:ring-0 text-white placeholder-slate-500 font-bold text-base px-2 py-3 dir-rtl text-right"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")}
                  className="px-4 py-2.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-black transition ml-1"
                >
                  مسح
                </button>
              )}
            </div>
          </div>
        </motion.div>

        {/* Toolbar Filters: Categories, Sort-by options, View state */}
        <div className="mt-12 flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800/50 pb-6 max-w-6xl mx-auto px-2">
          
          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-2 w-full md:w-auto">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`relative px-5 py-2.5 rounded-2xl font-black text-sm transition-all duration-300 ${
                  selectedCategory === cat.id
                    ? "bg-indigo-650/20 text-indigo-400 border border-indigo-500/30 shadow-[0_0_15px_rgba(79,70,229,0.15)]"
                    : "bg-[#12151e] text-slate-400 border border-slate-800/50 hover:bg-slate-800/30 hover:text-white"
                }`}
              >
                <span>{cat.label}</span>
              </button>
            ))}
          </div>

          {/* Sort By & View Toggles */}
          <div className="flex items-center justify-between gap-4 w-full md:w-auto mt-2 md:mt-0">
            <div className="flex items-center gap-2 bg-[#12151e] border border-slate-800/50 px-3 py-1.5 rounded-2xl">
              <SlidersHorizontal className="w-4 h-4 text-slate-400" />
              <span className="text-xs font-bold text-slate-400">ترتيب حسب:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent text-xs font-black text-white border-0 focus:ring-0 focus:outline-none cursor-pointer"
              >
                <option value="latest" className="bg-[#12151e] text-white">الأحدث مضافاً</option>
                <option value="rating" className="bg-[#12151e] text-white">الأعلى تقييماً</option>
                <option value="premium" className="bg-[#12151e] text-white">نسخ بريميوم</option>
                <option value="size" className="bg-[#12151e] text-white">الأصغر حجماً</option>
              </select>
            </div>

            {/* View Mode Grid/List buttons */}
            <div className="flex items-center bg-[#0a0c14] p-1 rounded-xl border border-slate-800/50">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-1.5 rounded-lg transition ${
                  viewMode === "grid" 
                    ? "bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 shadow-sm" 
                    : "text-slate-500 hover:text-slate-200"
                }`}
                title="عرض شبكة"
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-1.5 rounded-lg transition ${
                  viewMode === "list" 
                    ? "bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 shadow-sm" 
                    : "text-slate-500 hover:text-slate-200"
                }`}
                title="عرض قائمة"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
