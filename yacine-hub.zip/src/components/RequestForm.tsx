import { useState, useEffect, FormEvent } from "react";
import { PlusCircle, SearchCode, Clock, Send, ShieldCheck, HelpCircle, ClipboardList, CheckCircle } from "lucide-react";
import { AppRequest } from "../types";
import { motion } from "motion/react";

export default function RequestForm() {
  const [appName, setAppName] = useState("");
  const [appType, setAppType] = useState<"app" | "game">("app");
  const [note, setNote] = useState("");
  const [submittedRequests, setSubmittedRequests] = useState<AppRequest[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);

  // Seed sample global requests for a live community vibe
  const seedRequests: AppRequest[] = [
    {
      id: "req-1",
      appName: "CapCut Pro v18.2.0 (Arabic fix)",
      type: "app",
      note: "النسخة تعمل مجاناً مع تجميد الخطوط العربية",
      status: "available",
      createdAt: "قبل 6 ساعات"
    },
    {
      id: "req-2",
      appName: "GTA 5 Lite for Android",
      type: "game",
      note: "نرجو توفير نسخة خفيفة الحجم للاندرويد الضعيف",
      status: "processing",
      createdAt: "قبل يوم"
    },
    {
      id: "req-3",
      appName: "Ibispaint X Premium",
      type: "app",
      note: "توفير كل الفرش الذهبية مغلقة المصدر",
      status: "pending",
      createdAt: "قبل يومين"
    }
  ];

  useEffect(() => {
    const saved = localStorage.getItem("yacine_hub_requests");
    if (saved) {
      setSubmittedRequests(JSON.parse(saved));
    } else {
      setSubmittedRequests(seedRequests);
      localStorage.setItem("yacine_hub_requests", JSON.stringify(seedRequests));
    }
  }, []);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!appName.trim()) return;

    const newRequest: AppRequest = {
      id: `req-${Date.now()}`,
      appName: appName.trim(),
      type: appType,
      note: note.trim() || "يرجى توفير أحدث نسخة مفعّلة وآمنة",
      status: "pending",
      createdAt: "الآن"
    };

    const updated = [newRequest, ...submittedRequests];
    setSubmittedRequests(updated);
    localStorage.setItem("yacine_hub_requests", JSON.stringify(updated));

    // Clear Form & Show Success Banner
    setAppName("");
    setNote("");
    setAppType("app");
    setShowSuccess(true);
    setTimeout(() => {
      setShowSuccess(false);
    }, 4000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 md:py-12 text-right">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <h2 className="text-3xl font-black text-white">
          اطلب من المطور مباشرة 💎
        </h2>
        <p className="mt-2 text-sm text-slate-400 font-semibold">
          هل هناك لعبة أو تطبيق برو غير متوفر في المتجر؟ اكتب اسمه وسنقوم فوراً بفحصه وترقيته ورفعه على خوادم ميديا فاير من أجلك.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Request Submission Form */}
        <div className="lg:col-span-5 bg-[#12151e] border border-slate-800 rounded-[2rem] p-6 shadow-md relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-xl pointer-events-none"></div>

          <h3 className="text-lg font-black text-white mb-6 flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-indigo-400" />
            <span>نموذج طلب تطبيق جديد</span>
          </h3>

          {showSuccess && (
            <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-2xl font-bold text-xs flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              <span>تم تسجيل طلبك بنجاح! سيتم رفعه خلال قصة اليوم على السيرفر.</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* App title */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300">اسم التطبيق أو اللعبة بالكامل:</label>
              <input 
                type="text" 
                value={appName}
                onChange={(e) => setAppName(e.target.value)}
                required
                placeholder="مثال: PicsArt Premium v24"
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              />
            </div>

            {/* Type selector toggle */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300">التصنيف الرئيسي:</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setAppType("app")}
                  className={`py-3 rounded-xl text-xs font-black transition ${
                    appType === "app"
                      ? "bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 shadow-sm"
                      : "bg-[#0a0c14] border border-slate-800 text-slate-400 font-bold hover:bg-slate-800/50"
                  }`}
                >
                  تطبيق تعديل/برو
                </button>
                <button
                  type="button"
                  onClick={() => setAppType("game")}
                  className={`py-3 rounded-xl text-xs font-black transition ${
                    appType === "game"
                      ? "bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 shadow-sm"
                      : "bg-[#0a0c14] border border-slate-800 text-slate-400 font-bold hover:bg-slate-800/50"
                  }`}
                >
                  لعبة حركية/ترفيهية
                </button>
              </div>
            </div>

            {/* Note context */}
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-300">تفاصيل أو ميزات مطلوبة بالتعديل (اختياري):</label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="تفعيل الخط العربي المخصص أو ميزات التصدير بدقة 4K..."
                rows={4}
                className="w-full px-4 py-3 bg-[#0a0c14] border border-slate-800 text-xs font-semibold rounded-xl focus:outline-none focus:border-indigo-500 text-white placeholder-slate-600"
              ></textarea>
            </div>

            {/* Submit button */}
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2.5 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl transition shadow-lg shadow-indigo-600/15"
            >
              <Send className="w-4 h-4 ml-1" />
              <span>إرسال الطلب للمراجعة الفورية</span>
            </button>
          </form>
        </div>


        {/* Right Side: Community Live request logger list */}
        <div className="lg:col-span-7 bg-[#12151e] border border-slate-800 rounded-[2rem] p-6 shadow-md">
          
          <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              <ClipboardList className="w-5 h-5 text-indigo-400" />
              <span>الطلبات النشطة (متابعة حية)</span>
            </h3>
            
            <span className="px-2.5 py-1 text-[10px] font-black bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded-full">
              {submittedRequests.length} طلبات
            </span>
          </div>

          <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1">
            {submittedRequests.map((req) => {
              const statusLabel = 
                req.status === "available" ? "متوفر الآن ✅" : 
                req.status === "processing" ? "قيد التوفير 🚀" : "قيد الفحص والمراجعة 🔍";
                
              const statusColor = 
                req.status === "available" ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" : 
                req.status === "processing" ? "text-indigo-400 bg-indigo-500/10 border border-indigo-500/20" : 
                "text-pink-400 bg-pink-500/10 border border-pink-500/20";

              return (
                <div 
                  key={req.id}
                  className="p-4 bg-[#0a0c14] border border-slate-850 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1 max-w-md">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-extrabold text-sm text-white">{req.appName}</span>
                      <span className="px-2 py-0.5 text-[8px] font-bold bg-indigo-500/10 text-indigo-300 rounded-md border border-indigo-500/20">
                        {req.type === "app" ? "تطبيق" : "لعبة"}
                      </span>
                    </div>
                    
                    <p className="text-[11px] text-slate-400 font-medium font-arabic">
                      ملحوظة اللاعب: {req.note}
                    </p>
                    
                    <span className="block text-[9px] text-slate-500 font-bold">
                      تاريخ الطلب: {req.createdAt}
                    </span>
                  </div>

                  <span className={`px-3 py-1.5 h-fit text-[10px] font-black rounded-xl border text-center ${statusColor}`}>
                    {statusLabel}
                  </span>
                </div>
              );
            })}
          </div>

        </div>

      </div>
    </div>
  );
}
