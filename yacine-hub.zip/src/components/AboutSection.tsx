import { ShieldCheck, HelpCircle, Server, Award, Terminal, Heart, ArrowRight } from "lucide-react";

export default function AboutSection() {
  const faqs = [
    {
      q: "هل التطبيقات والألعاب لديكم آمنة للاستخدام في الهاتف؟",
      a: "نعم ومؤكد بالتجربة! نحن نقوم بفك ضغط كل ملف APK (Decompile) وفحصه سحابياً عبر أكثر من 60 مضاد فيروسات شهير مثل VirusTotal قبل إتاحته للتنزيل الفوري مجاناً لضمان خلوّه تماماً من أي أكواد ضارة."
    },
    {
      q: "لماذا نعتمد حصرياً على خوادم MediaFire المباشرة؟",
      a: "تتميز خوادم ميديا فاير بأنها أسرع خوادم تمكن المستخدم من التنزيل بضغطة زر مفردة وبأقصى سرعة إنترنت متواجدة لديه دون تحديد سرعات أو مطالبة بعمل اشتراك مدفوع."
    },
    {
      q: "ما هى المدة المتوقعة لتنزيل تطبيق قمت بطلبه؟",
      a: "عادة يستغرق تحديث خوادمنا وإتاحة الرابط المباشر الآمن للتطبيق أو اللعبة المطلوبة ما بين ساعتين إلى 24 ساعة كحد أقصى تلتزم بها لجنة الصيانة والدعم لموقع ياسين هب."
    },
    {
      q: "هل الخدمة مجانية بالكامل أم سأطالب بالدفع مستقبلاً؟",
      a: "بكل سرور، الخدمة ستبقى مجانية 100% للأبد. رسالتنا تكمن في تقديم تعديلات خفيفة ومحسنة للهواتف ومساعدتكم في الوصول لأدواتكم المفضلة بيسر وبأقل مجهود."
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 md:py-16 text-right">
      
      {/* Brand Identity / Slogan Header */}
      <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-lg text-xs font-black">
          <Award className="w-4 h-4" />
          <span>الضمان والمصداقية الكاملة للمتجر</span>
        </div>
        
        <h2 className="text-3xl sm:text-4xl font-black text-white leading-tight">
          نبذة عن متجر <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 drop-shadow-[0_0_10px_rgba(168,85,247,0.2)]">Yacine Hub App Store</span>
        </h2>
        
        <p className="text-sm font-semibold text-slate-400 leading-relaxed max-w-2xl mx-auto">
          المتجر العربي الأول المتهم بتوفير أحدث نسخ البرو المدفوعة وتعديلات الألعاب الحصرية للهواتف الذكية بنقاء وجودة كاملة، بعيداً عن الاختصارات والروابط المضللة.
        </p>
      </div>

      {/* Grid Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        
        {/* Card 1 */}
        <div className="p-6 bg-[#12151e] border border-slate-800/80 rounded-3xl space-y-4 text-right hover:border-indigo-500/30 transition-all duration-305">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 hover:bg-emerald-500/20 flex items-center justify-center text-emerald-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="font-black text-base text-white">الأمان الكامل للملفات</h3>
          <p className="text-xs text-slate-400 font-medium leading-relaxed">
            تم فحص حزمة التثبيت بالكامل واستخراج الأكواد المشبوهة وتوفير التنزيل الآمن النظيف بنسبة 100% لضمان حماية معلومات هاتفك.
          </p>
        </div>

        {/* Card 2 */}
        <div className="p-6 bg-[#12151e] border border-slate-800/80 rounded-3xl space-y-4 text-right hover:border-indigo-500/30 transition-all duration-305">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 hover:bg-indigo-500/20 flex items-center justify-center text-indigo-400">
            <Server className="w-6 h-6" />
          </div>
          <h3 className="font-black text-base text-white">خوادم MediaFire مباشرة</h3>
          <p className="text-xs text-slate-400 font-medium leading-relaxed">
            لا نستخدم أي روابط ملتوية أو إعلانات منبثقة مزعجة. بمجرد انتهاء الفحص الفني، يتم نقلك فوراً لتحميل الملف من ميديا فاير.
          </p>
        </div>

        {/* Card 3 */}
        <div className="p-6 bg-[#12151e] border border-slate-800/80 rounded-3xl space-y-4 text-right hover:border-indigo-500/30 transition-all duration-305">
          <div className="w-12 h-12 rounded-2xl bg-pink-500/10 hover:bg-pink-500/20 flex items-center justify-center text-pink-400">
            <Terminal className="w-6 h-6" />
          </div>
          <h3 className="font-black text-base text-white">برمجة مخصصة وخفيفة</h3>
          <p className="text-xs text-slate-400 font-medium leading-relaxed">
            محتوى التطبيقات خفيف جداً، ومناسب للأجهزة الضعيفة والمتوسطة مع تعديل واجهات الاستخدام وحجم البيانات لتوفير مساحة الذاكرة الاستيعابية.
          </p>
        </div>

      </div>

      {/* Frequently Asked Questions */}
      <div className="space-y-6">
        <h3 className="text-xl font-black text-white border-b border-slate-800 pb-3 flex items-center gap-2 justify-end">
          <HelpCircle className="w-5 h-5 text-indigo-400" />
          <span>الأسئلة الأكثر تداولاً والشرح بالتفصيل</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {faqs.map((faq, idx) => (
            <div 
              key={idx}
              className="p-5 bg-[#12151e] border border-slate-800/60 rounded-2xl space-y-2 text-right hover:border-slate-800 group transition duration-150"
            >
              <h4 className="font-black text-sm text-indigo-300 group-hover:text-indigo-200 transition">
                {faq.q}
              </h4>
              <p className="text-xs text-slate-400 font-medium leading-relaxed">
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
