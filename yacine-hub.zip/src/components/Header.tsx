import { useState } from "react";
import { Download, ShieldCheck, Moon, Sun, Menu, X, AppWindow, PlusCircle, Info, Heart, Award, ClipboardList } from "lucide-react";

interface HeaderProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  activeTab: "store" | "request" | "about" | "favorites" | "add-app";
  setActiveTab: (tab: "store" | "request" | "about" | "favorites" | "add-app") => void;
  downloadCount: number;
  openDownloadDrawer: () => void;
  favCount: number;
}

export default function Header({
  darkMode,
  setDarkMode,
  activeTab,
  setActiveTab,
  downloadCount,
  openDownloadDrawer,
  favCount
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: "store", label: "المتجر الرئيسي", icon: AppWindow },
    { id: "add-app", label: "إضافة تطبيق", icon: PlusCircle },
    { id: "request", label: "طلبات الأعضاء", icon: ClipboardList },
    { id: "about", label: "من نحن والضمان", icon: Info },
  ] as const;

  return (
    <header className="sticky top-0 z-50 transition-all duration-300 backdrop-blur-md bg-[#0a0c14]/90 border-b border-slate-800/50 shadow-[0_4px_30px_rgba(0,0,0,0.4)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo Section */}
          <div className="flex items-center gap-3">
            <div className="relative group cursor-pointer animate-pulse-slow" onClick={() => setActiveTab("store")}>
              <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-indigo-500 to-cyan-500 blur-md opacity-40 group-hover:opacity-100 transition duration-300"></div>
              <img 
                src="https://i.ibb.co/x8SNX4z0/IMG-20260622-025901.png" 
                alt="Yacine Hub Logo" 
                className="relative w-12 h-12 rounded-full object-cover border-2 border-indigo-500 bg-[#12151e] shadow-[0_0_15px_rgba(99,102,241,0.3)]"
              />
            </div>
            
            <div className="flex flex-col select-none" onClick={() => setActiveTab("store")}>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 drop-shadow-[0_0_10px_rgba(168,85,247,0.2)]">
                  Yacine Hub
                </span>
                <span className="px-1.5 py-0.5 text-[9px] font-bold rounded bg-indigo-600/20 text-indigo-300 border border-indigo-500/30">
                  PRO
                </span>
              </div>
              <span className="text-[10px] font-semibold text-slate-400 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400 inline" />
                متجر رسمي آمن 100%
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-reverse space-x-1 lg:space-x-2">
            {navItems.map((item) => {
              const IconComp = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-tab-${item.id}`}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm transition-all duration-200 ${
                    isActive
                      ? "bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 shadow-[0_0_15px_rgba(79,70,229,0.15)]"
                      : "text-slate-400 hover:text-white hover:bg-slate-800/30"
                  }`}
                >
                  <IconComp className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
            
            <button
              onClick={() => setActiveTab("favorites")}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm transition-all duration-200 relative ${
                activeTab === "favorites"
                  ? "bg-pink-600/20 text-pink-400 border border-pink-500/30 shadow-[0_0_15px_rgba(219,39,119,0.15)]"
                  : "text-slate-400 hover:text-pink-400 hover:bg-pink-950/10"
              }`}
            >
              <Heart className={`w-4 h-4 ${activeTab === "favorites" ? "fill-current text-pink-400" : ""}`} />
              <span>المفضلة</span>
              {favCount > 0 && (
                <span className="absolute -top-1 -left-1 px-1.5 py-0.5 text-[10px] bg-pink-500 text-white font-extrabold rounded-full animate-bounce">
                  {favCount}
                </span>
              )}
            </button>
          </nav>

          {/* Actions & Utilities Bar */}
          <div className="hidden md:flex items-center gap-3">
            {/* Safe Status Badge */}
            <div className="flex items-center gap-1.5 bg-[#12151e] px-3 py-1.5 rounded-xl border border-slate-800/50 shadow-inner">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              <span className="text-xs font-bold text-slate-300">
                السيرفر متصل وآمن
              </span>
            </div>

            {/* Dark Mode toggle button (Always dark in immersive UI, but we keep button for toggle status nicely styled) */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2.5 rounded-xl bg-[#12151e] border border-slate-800/50 text-slate-300 hover:bg-slate-800/50 hover:text-white transition duration-150"
              title={darkMode ? "الوضع المضيء" : "الوضع المظلم"}
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            {/* Download Drawer Button */}
            <button
              onClick={openDownloadDrawer}
              className="relative flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 hover:bg-indigo-600 hover:text-white hover:border-indigo-600 transition-all font-bold text-sm shadow-[0_0_20px_rgba(79,70,229,0.1)]"
            >
              <Download className="w-4 h-4 animate-bounce text-indigo-400 hover:text-white" />
              <span>التنزيلات النشطة</span>
              {downloadCount > 0 && (
                <span className="relative flex h-5 w-5 items-center justify-center rounded-full bg-indigo-500 text-white font-black text-xs animate-pulse">
                  {downloadCount}
                </span>
              )}
            </button>
          </div>

          {/* Mobile Hamburguer & Quick Action Menu Buttons */}
          <div className="flex items-center gap-2 md:hidden">
            {/* Download Drawer button */}
            <button
              onClick={openDownloadDrawer}
              className="relative p-2.5 rounded-xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400"
            >
              <Download className="w-5 h-5" />
              {downloadCount > 0 && (
                <span className="absolute -top-1 -left-1 flex h-5 w-5 items-center justify-center rounded-full bg-[#12151e] text-indigo-450 border border-indigo-500/20 font-black text-xs">
                  {downloadCount}
                </span>
              )}
            </button>

            {/* Menu Trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl bg-[#12151e] border border-slate-800/50 text-slate-300"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-800/50 bg-[#0a0c14]/95 py-4 px-4 shadow-inner space-y-2">
          {navItems.map((item) => {
            const IconComp = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl font-bold text-sm transition-all ${
                  isActive
                    ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30"
                    : "text-slate-400 hover:bg-slate-800/30 hover:text-white"
                }`}
              >
                <IconComp className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
          
          <button
            onClick={() => {
              setActiveTab("favorites");
              setMobileMenuOpen(false);
            }}
            className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl font-bold text-sm transition-all ${
              activeTab === "favorites"
                ? "bg-pink-500/20 text-pink-400 border border-pink-500/30"
                : "text-slate-400 hover:text-pink-400 hover:bg-pink-950/10"
            }`}
          >
            <Heart className={`w-5 h-5 ${activeTab === "favorites" ? "fill-current text-pink-400" : ""}`} />
            <span>المفضلة</span>
            {favCount > 0 && (
              <span className="ml-auto px-2 py-0.5 text-xs bg-pink-500 text-white font-extrabold rounded-full">
                {favCount}
              </span>
            )}
          </button>

          <div className="pt-3 border-t border-slate-800/50 flex justify-between items-center px-2">
            <span className="text-xs text-slate-400">سيرفر التحميلات المباشرة:</span>
            <span className="text-xs font-bold text-emerald-400">● نشط ومأمون 100%</span>
          </div>
        </div>
      )}
    </header>
  );
}
