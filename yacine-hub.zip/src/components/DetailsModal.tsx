import { useState, FormEvent } from "react";
import { X, Star, Download, ShieldCheck, Cpu, HardDrive, CalendarDays, ExternalLink, Send, ArrowRight, CornerDownLeft } from "lucide-react";
import { AppItem, Comment } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface DetailsModalProps {
  item: AppItem;
  onClose: () => void;
  onDownload: (item: AppItem) => void;
  onAddComment: (itemId: number, comment: Omit<Comment, "id" | "date">) => void;
  onDeleteApp?: (itemId: number) => void;
}

export default function DetailsModal({
  item,
  onClose,
  onDownload,
  onAddComment,
  onDeleteApp
}: DetailsModalProps) {
  const [activeScreen, setActiveScreen] = useState(0);
  const [authorName, setAuthorName] = useState("");
  const [reviewText, setReviewText] = useState("");
  const [reviewRating, setReviewRating] = useState(5);
  const [commentSuccess, setCommentSuccess] = useState(false);

  const handleSubmitComment = (e: FormEvent) => {
    e.preventDefault();
    if (!authorName.trim() || !reviewText.trim()) return;

    onAddComment(item.id, {
      author: authorName,
      content: reviewText,
      rating: reviewRating
    });

    setAuthorName("");
    setReviewText("");
    setReviewRating(5);
    setCommentSuccess(true);
    setTimeout(() => {
      setCommentSuccess(false);
    }, 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto bg-black/80 backdrop-blur-sm transition-all text-right">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-4xl bg-[#0a0c10] border border-slate-800 rounded-[2.5rem] shadow-2xl p-6 md:p-8 overflow-hidden max-h-[90vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 bg-slate-800 hover:bg-slate-705 text-slate-300 rounded-full transition duration-150 z-10"
          title="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-indigo-505/10 rounded-full blur-2xl pointer-events-none"></div>

        {/* Modal App Header */}
        <div className="flex flex-col md:flex-row items-center md:items-start gap-6 border-b border-slate-800 pb-6">
          <img 
            src={item.icon} 
            alt={item.title} 
            className="w-24 h-24 rounded-[1.75rem] object-cover shadow-lg border border-slate-800 bg-[#0a0c14]"
            referrerPolicy="no-referrer"
          />
          
          <div className="flex-1 space-y-3 text-center md:text-right">
            <div className="flex flex-col md:flex-row md:items-center gap-2.5">
              <h2 className="text-2xl font-black text-white">{item.title}</h2>
              <span className="inline-block mx-auto md:mx-0 px-3 py-1 bg-indigo-600 text-white font-bold text-xs rounded-full shadow-sm">
                {item.tag}
              </span>
            </div>

            <p className="text-sm font-semibold text-slate-400">
              المطور: <span className="text-indigo-400 font-bold">{item.developer}</span>
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs font-bold text-slate-300">
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>إصدار نقي 100%</span>
              </div>
              <div className="flex items-center gap-1 text-amber-500">
                <Star className="w-4 h-4 fill-current" />
                <span>{item.rating}</span>
                <span className="text-slate-500">({item.comments.length} تقييمات)</span>
              </div>
              <div className="text-slate-700">|</div>
              <div>التنزيلات: {item.downloadsCount}</div>
            </div>
          </div>

          {/* Quick Download Anchor */}
          <div className="mt-4 md:mt-0 w-full md:w-auto flex flex-col sm:flex-row gap-3">
            {onDeleteApp && (
              <button
                onClick={() => {
                  if (confirm("هل أنت متأكد من رغبتك في حذف هذا التطبيق نهائياً من المتجر؟")) {
                    onDeleteApp(item.id);
                  }
                }}
                className="px-5 py-3.5 bg-rose-600/15 hover:bg-rose-600 text-rose-400 hover:text-white border border-rose-500/35 rounded-2xl transition duration-150 text-xs font-black"
              >
                حذف التطبيق 🗑️
              </button>
            )}
            <button
              onClick={() => onDownload(item)}
              className="flex-grow flex items-center justify-center gap-3 px-8 py-4 bg-indigo-600 hover:bg-indigo-550 text-white font-bold rounded-2xl shadow-xl shadow-indigo-600/20 transform hover:-translate-y-0.5 transition duration-150"
            >
              <Download className="w-5 h-5 animate-bounce" />
              <span>تحميل مباشر الآن 🚀</span>
            </button>
          </div>
        </div>

        {/* Modal Info Meta Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-6 border-b border-slate-800">
          <div className="flex items-center gap-3 p-3 bg-[#12151e] border border-slate-800/80 rounded-2xl">
            <Cpu className="w-5 h-5 text-indigo-400 flex-shrink-0" />
            <div>
              <p className="text-[10px] text-slate-500 font-bold">رقم الإصدار</p>
              <p className="text-xs font-black text-white" dir="ltr">{item.version}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 p-3 bg-[#12151e] border border-slate-800/80 rounded-2xl">
            <HardDrive className="w-5 h-5 text-indigo-400 flex-shrink-0" />
            <div>
              <p className="text-[10px] text-slate-500 font-bold">الحجم الكلي</p>
              <p className="text-xs font-black text-white" dir="ltr">{item.size}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 p-3 bg-[#12151e] border border-slate-800/80 rounded-2xl">
            <CalendarDays className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <div>
              <p className="text-[10px] text-slate-500 font-bold">التصنيف مخصص</p>
              <p className="text-xs font-black text-white">
                {item.type === "app" ? "تطبيقات برو" : "ألعاب أندرويد"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-[#12151e] border border-slate-800/80 rounded-2xl">
            <ShieldCheck className="w-5 h-5 text-pink-400 flex-shrink-0" />
            <div>
              <p className="text-[10px] text-slate-500 font-bold">الحالة الأمنية</p>
              <p className="text-xs font-black text-emerald-400">آمن ومصدّق ✅</p>
            </div>
          </div>
        </div>

        {/* Slides/Screenshots Carousel & Full Description layout */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 py-6">
          
          {/* Detailed text */}
          <div className="md:col-span-3 space-y-4">
            <h3 className="text-lg font-black text-white">وصف وحقائق عن التعديل:</h3>
            <p className="text-sm text-slate-350 leading-relaxed font-semibold font-arabic">
              {item.fullDesc}
            </p>
            
            <div className="p-4 bg-[#12151e] border border-slate-800 rounded-2xl space-y-2">
              <h4 className="text-xs font-black text-indigo-300">💡 مميزات إضافية حصرية في Yacine Hub:</h4>
              <ul className="text-xs text-slate-400 space-y-1 list-disc list-inside col bg-transparent">
                <li>روابط تنزيل فورية ومباشرة بدون إعلانات معرقلة.</li>
                <li>تحديثات دورية وسريعة متوافقة مع جميع التحديثات الرسمية.</li>
                <li>إمكانية طلب إضافات وتعديلات للعبة أو التطبيق عبر زر الطلبات المباشر.</li>
              </ul>
            </div>
          </div>

          {/* Screenshot Slider preview */}
          <div className="md:col-span-2 space-y-3">
            <h3 className="text-lg font-black text-white">لقطات الشاشة للتجربة:</h3>
            
            <div className="relative h-48 bg-slate-900 rounded-2xl overflow-hidden border border-slate-800/80 shadow-inner">
              <img 
                src={item.screenshots[activeScreen] || item.screenshots[0]} 
                alt="App screenshot" 
                className="w-full h-full object-cover transition-all duration-300"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-2 text-center text-[10px] text-white font-bold">
                عرض تفاضلي للتطبيق
              </div>
            </div>

            {/* Pagination icons */}
            <div className="flex justify-center gap-2 overflow-x-auto pb-1">
              {item.screenshots.map((screen, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveScreen(idx)}
                  className={`w-14 h-10 rounded-lg overflow-hidden border-2 transition ${
                    activeScreen === idx ? "border-indigo-505 scale-105" : "border-transparent opacity-60"
                  }`}
                >
                  <img src={screen} alt="preview thumbnail" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Verification Checks & Comments section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-slate-800">
          
          {/* Comments List */}
          <div className="space-y-4">
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              📋 آراء المستخدمين وحالات التجربة
            </h3>

            <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
              {item.comments.map((comment) => (
                <div 
                  key={comment.id}
                  className="p-3.5 bg-[#12151e] border border-slate-800/85 rounded-2xl space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-black text-xs text-white">{comment.author}</span>
                    <span className="text-[10px] text-slate-500 font-bold">{comment.date}</span>
                  </div>
                  
                  <div className="flex text-amber-400" dir="ltr">
                    {Array.from({ length: 5 }).map((_, starIdx) => (
                      <Star 
                        key={starIdx} 
                        className={`w-3 h-3 ${starIdx < comment.rating ? "fill-current" : "opacity-30"}`} 
                      />
                    ))}
                  </div>

                  <p className="text-xs text-slate-400 leading-relaxed font-medium">
                    {comment.content}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Leave a Rating Form */}
          <div className="space-y-4">
            <h3 className="text-lg font-black text-white">✍️ شاركنا تجربتك وتقييمك</h3>
            
            {commentSuccess ? (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-2xl font-bold text-xs text-center">
                تم نشر تقييمك الموثق بنجاح! شكراً لمساعدتك في بناء الثقة بالمتجر.
              </div>
            ) : (
              <form onSubmit={handleSubmitComment} className="space-y-3">
                <input 
                  type="text" 
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  placeholder="اسمك الكريم" 
                  required
                  className="w-full px-4 py-3 bg-[#12151e] border border-slate-800 text-xs font-bold rounded-xl focus:outline-none focus:border-indigo-550 text-white placeholder-slate-600"
                />

                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-slate-300">التقييم بالنجوم:</span>
                  <div className="flex gap-1 text-amber-400 cursor-pointer" dir="ltr">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setReviewRating(star)}
                        className="focus:outline-none bg-transparent border-0 p-0"
                      >
                        <Star className={`w-5 h-5 ${star <= reviewRating ? "fill-current" : "opacity-30"}`} />
                      </button>
                    ))}
                  </div>
                </div>

                <textarea
                  value={reviewText}
                  onChange={(e) => setReviewText(e.target.value)}
                  placeholder="اكتب مراجعتك عن التطبيق/اللعبة ومدى رضاك..." 
                  required
                  rows={3}
                  className="w-full px-4 py-3 bg-[#12151e] border border-slate-800 text-xs font-medium rounded-xl focus:outline-none focus:border-indigo-550 text-white placeholder-slate-600"
                ></textarea>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl transition shadow-lg shadow-indigo-600/15"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>إرسال التقييم الموثق</span>
                </button>
              </form>
            )}
          </div>

        </div>

      </motion.div>
    </div>
  );
}
